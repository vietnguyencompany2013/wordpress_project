<div id="footer">
  <div class="container_12">
    <?php do_action( 'cell_footer' ); ?>
  </div>
</div>

</div> <!-- end .container_main -->
<?php wp_footer(); ?>
</body>
</html>
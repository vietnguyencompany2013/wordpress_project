=== Cell – Free WordPress Theme ===

Cell is a clean, lightweight WordPress theme allowing you to create any type of website you want. Cell features: custom background, drop-down menu, header logo, highly customizable and adaptable, theme options, post excerpts with thumbnails, SEO friendly, translation ready, W3C valid, widget-ready, threaded comments & more. It is tested major browsers – Mozilla Firefox, Internet Explorer, Opera, Safari and Chrome. Cell theme is perfect for all WordPress user and theme developer who wants create premium theme from the scratch.

=== About Primary Menu ===

Primary Menu of Cell is best optimized with five to six top level navigation links.

=== Designed by DesignOrbital.com ===

http://designorbital.com/cell/

=== Support ===

http://designorbital.com/
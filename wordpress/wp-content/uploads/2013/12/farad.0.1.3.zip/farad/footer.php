  <div id="footer">
    <div class="container_16">
      <?php do_action( 'farad_footer' ); ?>
    </div>
  </div>

</div> <!-- end .wrapper -->
<?php wp_footer(); ?>
</body>
</html>